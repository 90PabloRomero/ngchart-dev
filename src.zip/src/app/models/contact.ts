export class Contact{
	ID:number;
	Name:  string;
}




