export class ContactRight{
	ID:number;
	ContactID: number
	Itemtype:  string // tree node, sheet node, sheet
	Optype:    string //additional,exception
	See:       boolean
	Modify:    boolean
	Del:       boolean
}


