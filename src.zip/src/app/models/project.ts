export class Project{
	ID:number;
	ProjectName:  string;
	Data:  string;
	UserId: number;
}


